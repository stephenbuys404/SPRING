package tacos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest                 // <1>
public class TacoCloudApplicationTests {

  @Test                         // <2>
  public void contextLoads() {
  }

}
